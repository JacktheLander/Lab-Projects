#include <stdio.h>
#include <stdlib.h>
#include <math.h>

FILE *cfile;
FILE *vfile;


int main(int argc, char *argv[]) {
	
	cfile = fopen("c_outputwave.txt", "r");
	vfile = fopen("outputwave.txt", "r");
	
	int cval, vval;
	int carray[200], varray[200];
	double accuracy, minaccuracy, avgerror;
	int min;	

	avgerror = 0;
	for(int i=0; i<200; i++){
		fscanf(cfile, "%04x", &carray[i]);
		fscanf(vfile, "%04x", &varray[i]);

		//printf("%d, %d\n", (int)carray[i], (int)varray[i]);
		cval = (int)carray[i];
		vval = (int)varray[i];
		
		if((cval != 0) && (vval != 0)){
			accuracy = ((double)vval)/((double)cval);}
		else{
			accuracy = 1;} //assumed as when we look at the data there are no errors at 0		

		if(accuracy>1){
			accuracy = 2-accuracy;}

		if(i==0 || accuracy < minaccuracy){
			minaccuracy = accuracy;
			min = i;}

		avgerror = avgerror + (1-accuracy);

		printf("output %d, v output = %04x, c output = %04x, accuracy = %f%\n", i, varray[i], carray[i], accuracy*100);
	}
	avgerror = avgerror/2;

	printf("\nLargest error = %f%, difference of %04x\nAverage error = %f%\n", (1-minaccuracy)*100, ((int)varray[min]-(int)carray[min]), avgerror);
	if((int)avgerror != 0){
		printf("\n--- Test Failed ---\n\n");
	}
	else{
		printf("\n--- Test Passed ---\n\n");
	}
}	
