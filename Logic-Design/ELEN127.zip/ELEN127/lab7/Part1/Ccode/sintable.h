void fill_wavetable();
int table_lookup(int phase);
void clearPhaseAcc();
int incPhase();
int getPhase();
void setPhaseReg(int phaseinc);

