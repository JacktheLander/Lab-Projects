#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define LENGTH 128
#define SIN_SCALE 0.99999
#define WAVETABLE_RANGE (double)(1<<8)
#define WAVETABLE_OUTPUT_MASK ((1<<8)-1)

FILE *outfile;

int main(int argc, char*argv[]){
    int address;
	int out;
	double phase;
    outfile = fopen("wavetable.txt", "w");
    printf("Start of data writing\n\n");
    for(int j = 0; j < LENGTH; j++){
		phase = ((double)j*2*3.14159)/(double)LENGTH;
        out = (0.5*SIN_SCALE*WAVETABLE_RANGE*(1 + sin(phase)));
		out = (int)out & WAVETABLE_OUTPUT_MASK;
		address = j*12;
        fprintf(outfile, "%04x\n", phase, out);
    }
    fclose(outfile);
    return 0;
}
